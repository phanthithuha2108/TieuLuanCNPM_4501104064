﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PHANTHITHUHA_4501104064
{
    public partial class Quanlyve : Form
    {
        public Quanlyve()
        {
            InitializeComponent();
        }
    }
}
